#include <stdio.h>

// 1: declaration of print_line
void print_line(char line[], int length);

// Exercise part 1: create declaration of print_twice here

int main(void)
{
    // open the file fruit.txt
    FILE* p_file = fopen("fruit.txt", "r");

    // check if file exists
    if (p_file == NULL)
    {
        printf("Error file fruit.txt does not exist.\n");
		return 1;
    }

    // create a char buffer to write the characters to
    char line_buffer[80] = {};

    // read file line by line and print
    int n_characters;
    while((n_characters = fread(line_buffer, 1, 80, p_file)) > 0)
    {
        // 2: call to print_line
        print_line(line_buffer, n_characters-1);

        // Exercise part 2: remove print_line and call your function print_twice here
    }

    // close file
    fclose(p_file);
}

// 3: implementation of print_line
void print_line(char line[], int length)
{
    for(int i = 0; i < length; i++)
    {
        printf("%c", line[i]);
    }
    printf("\n");
}

// Exercise part 3: implement your function print_twice here
