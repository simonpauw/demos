compile:
make hello-file-io

run:
./hello-file-io

run valgrind:
valgrind ./hello-file-io

run valgrind more info:
valgrind --leak-check=full --show-leak-kinds=all ./hello-file-io

fix:
add `fopen` add the end of the main function
