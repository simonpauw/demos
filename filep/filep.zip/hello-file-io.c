#include <stdio.h>

int main(void)
{
    FILE* p_file = fopen("hello.txt", "r");
    char line_buffer[80] = {};

    if (p_file == NULL)
    {
        printf("Error file hello.txt does not exist.\n");
		return 1;
    }
    int chars_read = fread(line_buffer, 1, 80, p_file);

    printf("Number of characters read: %i\n", chars_read);
    printf("%s\n", line_buffer);

    p_file = NULL;

}